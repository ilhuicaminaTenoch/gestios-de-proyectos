
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		
			   
					<div class="alert alert-danger">
						<ul>
							
								<li><?php echo e($errores); ?></li>
							
						</ul>
					</div>
				
		
		
	</div>
</div>

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Codigos/Barras/mensaje.blade.php ENDPATH**/ ?>