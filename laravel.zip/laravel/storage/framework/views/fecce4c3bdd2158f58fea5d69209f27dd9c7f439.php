
<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <search-person></search-person>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Gestion/BarCode/index.blade.php ENDPATH**/ ?>