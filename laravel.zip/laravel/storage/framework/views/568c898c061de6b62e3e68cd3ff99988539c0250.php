<!DOCTYPE html>
<html>
<head>
    <title>hola</title>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
    </style>
</head>
<body>

<table class="table table-striped">
    <?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($hab->nombre); ?></td>
            <td><?php echo e($hab->compania); ?></td>
            
            <td>
                <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($hab->QR, 'QRCODE', 5,5)); ?>"
                     alt="barcode"/>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/pdf_downloadH.blade.php ENDPATH**/ ?>