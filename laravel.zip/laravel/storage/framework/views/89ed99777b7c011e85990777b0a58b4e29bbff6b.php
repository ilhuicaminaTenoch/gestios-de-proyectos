
<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-md-6 col-xs-12">
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">


        <div class="col-md-6">
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e($Contratistas->id_contratista); ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <?php echo Form::model($Contratistas,['method'=>'PATCH', 'route'=>['Cat_Contratistas.update',$Contratistas->id_contratista], 'class'=>'form-horizontal']); ?>

                <?php echo e(Form::token()); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">Nombre</label>

                            <div class="col-sm-10">
                                <input type="text" name="nombre" class="form-control" value="<?php echo e($Contratistas->nombre); ?>"
                                       placeholder="Nombre del contratista...">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label">Compañia</label>

                            <div class="col-sm-10">
                                <select id="id_compania" name="id_compania" class="form-control">
                                    <?php $__currentLoopData = $Compania; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($comp->id_compania==$Contratistas->id_compania): ?>
                                            <option value="<?php echo e($comp->id_compania); ?>" selected><?php echo e($comp->compania); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($comp->id_compania); ?>"><?php echo e($comp->compania); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">Puesto</label>

                            <div class="col-sm-10">
                                <select id="id_puesto" name="id_puesto" class="form-control">
                                    <?php $__currentLoopData = $Puesto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($pue->id_puesto==$Contratistas->id_puesto): ?>
                                            <option value="<?php echo e($pue->id_puesto); ?>" selected><?php echo e($pue->puesto); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($pue->id_puesto); ?>"><?php echo e($pue->puesto); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">Tipo</label>

                            <div class="col-sm-10">
                                <select id="tipo" name="tipo" class="form-control">

                                    <?php if($Contratistas->tipo==1): ?>
                                        {
                                        <option value="<?php echo e($Contratistas->tipo); ?>" selected>Tipo<?php echo e($Contratistas->tipo); ?></option>
                                        <option value="2">Tipo2</option>
                                        }


                                    <?php else: ?>
                                        {
                                        <option value="<?php echo e($Contratistas->tipo); ?>" selected>Tipo<?php echo e($Contratistas->tipo); ?></option>
                                        <option value="1">Tipo1</option>
                                        }

                                    <?php endif; ?>

                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">Seguro Social</label>

                            <div class="col-sm-10">
                                <input type="text" name="RFC" class="form-control" value="<?php echo e($Contratistas->RFC); ?>" placeholder="RFC...">
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <a href="/Catalogos/Cat_Contratistas" class="btn btn-danger">Cancelar</a>
                        <button class="btn btn-info pull-right" type="submit">Guardar</button>
                    </div>
                    <!-- /.box-footer -->
                <?php echo Form::close(); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="box box-default">
                <div class="box-header with-border">
                    <i class="fa fa-bullhorn"></i>

                    <h3 class="box-title">Codigo QR</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body" style="text-align: center">
                    <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($Contratistas->nombre, 'QRCODE', 10,10)); ?>"
                         alt="barcode"/>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Catalogos/Cat_Contratistas/edit.blade.php ENDPATH**/ ?>