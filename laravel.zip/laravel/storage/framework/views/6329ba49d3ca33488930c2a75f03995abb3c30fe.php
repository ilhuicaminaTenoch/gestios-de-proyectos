<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-delete-<?php echo e($pues->id_puesto); ?>">
	
	<form action="/Catalogos/Cat_Puestos/destroy<?php echo e($pues->id_puesto); ?>" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>


	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Eliminar Puesto</h4>
			</div>
			<div class="modal-body">
				<p>Confirme si desea eliminar el puesto: <?php echo e($pues->puesto); ?></p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

				<a href="<?php echo e(URL::action('PuestoController@destroy',$pues->id_puesto)); ?>"><button class="btn btn-info">Confirmar</button></a>
			</div>
		</div>
	</div>
</form>
	
</div><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Catalogos/Cat_Puestos/modal.blade.php ENDPATH**/ ?>