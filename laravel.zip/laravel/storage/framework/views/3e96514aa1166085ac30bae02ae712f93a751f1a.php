
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Compañia</th>
					<th>Codigo</th>
				</thead>

				<?php $__currentLoopData = $Compania; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($compa->id_contratista); ?></td>
					<td><?php echo e($compa->nombre); ?></td>
					
					<td> <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($compa->nombre, 'QRCODE', 5,5)); ?>"
                              alt="barcode"/></td>

 				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($Compania->render()); ?>

	</div>
</div>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Codigos/Barras/edit.blade.php ENDPATH**/ ?>