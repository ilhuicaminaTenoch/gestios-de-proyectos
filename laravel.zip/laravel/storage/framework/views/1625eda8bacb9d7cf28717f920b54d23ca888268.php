<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
    </style>
</head>
<body>

<table class="table table-striped">
    <?php $__currentLoopData = $contratistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($contratista->nombre); ?></td>
            <td><?php echo e($contratista->compania); ?></td>
            <td>
                <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($contratista->nombre, 'QRCODE', 5,5)); ?>"
                     alt="barcode"/>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/pdf_download.blade.php ENDPATH**/ ?>