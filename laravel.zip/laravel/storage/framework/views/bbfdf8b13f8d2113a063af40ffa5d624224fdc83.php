<?php echo Form::open(array('url'=>'/Catalogos/Cat_Empresas','method'=>'GET', 'autocomplete'=>'off','role'=>'search')); ?>


<div class="form-group">
	<div class="input-group">
		<input type="text" name="searchText" class="form-control" placeholder="Buscar..." value="<?php echo e($searchText); ?>">
		<span class="input-group-btn">
			<button type="submit" class="btn btn-primary">Buscar</button>
		</span>
	</div>
</div>
<?php echo e(Form::close()); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Catalogos/Cat_Empresas/search.blade.php ENDPATH**/ ?>