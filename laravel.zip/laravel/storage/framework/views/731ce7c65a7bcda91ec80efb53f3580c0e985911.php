
<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<h3>Accesos</h3>
		<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
	</div>
</div>
		
		<form action="/Catalogos/Cat_Contratistas/<?php echo e($Contratistas->id_contratista); ?>" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>


		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="form-group">
					<label for="nombre">Inducción</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->induccion));
					?>
					<?php if($hab->induccion!=null): ?> 
					<input type="date" id="induccion" name="induccion" class="form-control" value="<?php echo e($fecha); ?>">
					 <?php else: ?> 
					  
						<input type="date" name="induccion" id="inducion" class="form-control" value="">
					 <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="form-group">
					<label for="nombre">Examen Médico</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha2=date('Y-m-d',strtotime($hab->examen_medico));
					?>
					<?php if($hab->examen_medico!=null): ?>

					<input type="date" name="examen_medico" id="examen_medico" class="form-control" value="<?php echo e($fecha2); ?>">
					 <?php else: ?> 
					 
						<input type="date" name="examen_medico" id="examen_medico" class="form-control" value="">
					 <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->diciembre==1): ?>
						<input type="checkbox" checked="checked" name="diciembre" class="form-check-input" id="diciembre">
					<?php else: ?>
						<input type="checkbox" class="form-check-input" name="diciembre" id="diciembre">
					<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				<label class="form-check-label" for="diciembre">Diciembre</label>
 
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->febrero==1): ?>
						<input type="checkbox" name="febrero" checked="checked" class="form-check-input" id="febrero">
					<?php else: ?>
						<input type="checkbox" class="form-check-input" name="febrero" id="febrero">
					<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				<label class="form-check-label" for="febrero">Febrero</label>
 
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					
 					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->abril==1): ?>
						<input type="checkbox" checked="checked" name="abril" class="form-check-input" id="abril">
						<?php else: ?> 
						<input type="checkbox"  name="abril" class="form-check-input" id="abril">
					<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    				<label class="form-check-label" for="abril">Abril</label>
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->junio==1): ?>
						<input type="checkbox" name="junio" checked="checked" class="form-check-input" id="junio">
					<?php else: ?>
						<input type="checkbox" name="junio" class="form-check-input" id="junio">
						<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    				
    				<label class="form-check-label" for="junio">Junio</label>
 	
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->agosto==1): ?>
					<input type="checkbox" name="agosto" checked="checked" class="form-check-input" id="agosto">
					<?php else: ?>
					<input type="checkbox" name="agosto" class="form-check-input" id="agosto">
					<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    				<label class="form-check-label" for="agosto">Agosto</label>
 
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="form-group">
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 					<?php if($hab->octubre==1): ?>
					<input type="checkbox" name="octubre" checked="checked" class="form-check-input" id="octubre">
					<?php else: ?>
					<input type="checkbox" name="octubre" class="form-check-input" id="octubre">
					<?php endif; ?>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    				<label class="form-check-label" for="octubre">Octubre</label>
 
				</div>
			</div>
			</div>
		<div class="row">

			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3>Habilidades</h3>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="alturas">Alturas</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->alturas));
					?>
					<?php if($hab->alturas!=null): ?>
					<input type="date" name="alturas" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="alturas" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="armado_a">Armado de andamios</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->armado_a));
					?>
					<?php if($hab->armado_a!=null): ?>
					<input type="date" name="armado_a" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="armado_a" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="plataforma_e">Plataforma Elevadora</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->plataforma_e));
					?>
					<?php if($hab->plataforma_e!=null): ?>
						<input type="date" name="plataforma_e" class="form-control" value="<?php echo e($fecha); ?>">
					 <?php else: ?> 
						<input type="date" name="plataforma_e" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="gruas_i">Gruas e izajes</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->gruas_i));
					?>
					<?php if($hab->gruas_i!=null): ?>
					<input type="date" name="gruas_i" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="gruas_i" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="montacargas">Montacargas</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->montacargas));
					?>
					<?php if($hab->montacargas!=null): ?>
						<input type="date" name="montacargas" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="montacargas" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="equipo_aux">Equipo Aux. de Carga</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->equipo_aux));
					?>
					<?php if($hab->equipo_aux!=null): ?>
						<input type="date" name="equipo_aux" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="equipo_aux" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="maquinaria_p">Maquinaria Pesada</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->maquinaria_p));
					?>
					<?php if($hab->maquinaria_p!=null): ?>
						<input type="date" name="maquinaria_p" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="maquinaria_p" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="e_confinados">E. Confinados</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->e_confinados));
					?>
					<?php if($hab->e_confinados!=null): ?>
					<input type="date" name="e_confinados" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="e_confinados" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="t_caliente">T. Caliente</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->t_caliente));
					?>
					<?php if($hab->t_caliente!=null): ?>
						<input type="date" name="t_caliente" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="t_caliente" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="t_electricos">T. Eléctricos</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->t_electricos));
					?>
					<?php if($hab->t_electricos!=null): ?>
						<input type="date" name="t_electricos" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="t_electricos" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="loto">L.O.T.O</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->loto));
					?>
					<?php if($hab->loto!=null): ?>
						<input type="date" name="loto" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="loto" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="apertura_I">Apertura de Líneas</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->apertura_l));
					?>
					<?php if($hab->apertura_l!=null): ?>
						<input type="date" name="apertura_l" class="form-control" value="<?php echo e($fecha); ?>">
					 <?php else: ?> 
						<input type="date" name="apertura_l" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="amoniaco">Amoniaco</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->amoniaco));
					?>
					<?php if($hab->amoniaco!=null): ?>
						<input type="date" name="amoniaco" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="amoniaco" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="quimicos">Químicos</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->quimicos));
					?>
					<?php if($hab->quimicos!=null): ?>
						<input type="date" name="quimicos" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="quimicos" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="temperatura_e">Temperaturas Elevadas</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->temperatura_e));
					?>
					<?php if($hab->temperatura_e!=null): ?>
						<input type="date" name="temperatura_e" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="temperatura_e" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<div class="form-group">
					<label for="temperatura_a">Temperaturas Abatidas</label>
					<?php $__currentLoopData = $Habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $fecha=date('Y-m-d',strtotime($hab->temperatura_a));
					?>
					<?php if($hab->temperatura_a!=null): ?>
						<input type="date" name="temperatura_a" class="form-control" value="<?php echo e($fecha); ?>">
					<?php else: ?> 
						<input type="date" name="temperatura_a" class="form-control" value="">
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</div>
			</div>
			</div>
			<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: right;">
					<div class="form-group">
						<button class="btn btn-primary" type="submit">Guardar</button>
						<a href="/Catalogos/Cat_Contratistas" class="btn btn-danger">Cancelar</a>
					</div>
				</div>
		</div>

		</form>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-gestion-de-contratistas\resources\views/Catalogos/Cat_Contratistas/agregarH.blade.php ENDPATH**/ ?>