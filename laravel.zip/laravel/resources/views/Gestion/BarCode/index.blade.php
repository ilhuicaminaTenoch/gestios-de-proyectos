@extends('layouts.admin')
@section('contenido')
    <div class="row">
        <search-person></search-person>
    </div>
@endsection
