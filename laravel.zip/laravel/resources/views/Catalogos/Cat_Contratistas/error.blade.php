@extends('layouts.admin')
@section('contenido')
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		
			   
					<div class="alert alert-danger">
						<ul>
							
								<li>{{$errores}}</li>
							
						</ul>
					</div>
				
		
		
	</div>
</div>

		
@endsection