<template>
    <div class="box box-success">
        <div class="box-header with-border">
            <h3 class="box-title">Componente VUEJS</h3>
        </div>

        <!-- /.box-body -->
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
