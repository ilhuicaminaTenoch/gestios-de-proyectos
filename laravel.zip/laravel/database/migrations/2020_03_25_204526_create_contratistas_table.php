<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContratistasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up()
    {
        Schema::create('contratistas', function (Blueprint $table) {
            $table->Increments('id_contratista');
            $table->string('nombre',150);
            $table->integer('id_compania');
            $table->integer('id_puesto');
            $table->integer('tipo');
            $table->string('RFC',15);
            $table->integer('activo');
            $table->string('codigo');  
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contratistas');
    }
}
